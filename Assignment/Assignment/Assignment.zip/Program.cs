﻿using System;

namespace A3_TextAdventureOOP
{
    class Program
    {
        static void Main(string[] args)
        {
            Game game = new InheritorGame();
            game.StartGame();
        }
    }
}
